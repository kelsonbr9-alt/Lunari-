import { type AppId, type AppDefinition } from "@shared/schema";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Globe, Terminal, FolderOpen, FileText, Search } from "lucide-react";
import { useState } from "react";

const APPS: AppDefinition[] = [
  {
    id: "browser",
    name: "Navegador Web",
    icon: "globe",
    description: "Navegue na internet",
  },
  {
    id: "terminal",
    name: "Terminal",
    icon: "terminal",
    description: "Execute comandos do sistema",
  },
  {
    id: "filemanager",
    name: "Gerenciador de Arquivos",
    icon: "folder",
    description: "Gerencie seus arquivos",
  },
  {
    id: "notes",
    name: "Bloco de Notas",
    icon: "file",
    description: "Edite arquivos de texto",
  },
];

interface StartMenuProps {
  onAppLaunch: (appId: AppId) => void;
  onClose: () => void;
}

export function StartMenu({ onAppLaunch, onClose }: StartMenuProps) {
  const [searchTerm, setSearchTerm] = useState("");

  const getIcon = (iconName: string) => {
    const iconClass = "h-5 w-5";
    switch (iconName) {
      case "globe":
        return <Globe className={iconClass} />;
      case "terminal":
        return <Terminal className={iconClass} />;
      case "folder":
        return <FolderOpen className={iconClass} />;
      case "file":
        return <FileText className={iconClass} />;
      default:
        return null;
    }
  };

  const filteredApps = APPS.filter(
    app =>
      app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      <div
        className="fixed inset-0 bg-black/20 backdrop-blur-sm"
        onClick={onClose}
        data-testid="start-menu-overlay"
      />
      <div
        className="absolute bottom-12 left-0 w-80 max-h-96 bg-popover border border-popover-border rounded-lg shadow-2xl overflow-hidden"
        data-testid="start-menu"
      >
        <div className="p-4 border-b border-popover-border">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Buscar aplicativos..."
              className="pl-9 h-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              data-testid="input-app-search"
            />
          </div>
        </div>

        <div className="p-2 max-h-80 overflow-y-auto">
          <div className="space-y-1">
            {filteredApps.map(app => (
              <Button
                key={app.id}
                variant="ghost"
                className="w-full justify-start h-auto p-3 hover-elevate active-elevate-2"
                onClick={() => onAppLaunch(app.id)}
                data-testid={`start-menu-app-${app.id}`}
              >
                <div className="flex items-center gap-3 w-full">
                  <div className="flex-shrink-0 text-primary">
                    {getIcon(app.icon)}
                  </div>
                  <div className="flex flex-col items-start flex-1 min-w-0">
                    <span className="text-sm font-medium text-popover-foreground">
                      {app.name}
                    </span>
                    <span className="text-xs text-muted-foreground truncate w-full">
                      {app.description}
                    </span>
                  </div>
                </div>
              </Button>
            ))}
          </div>

          {filteredApps.length === 0 && (
            <div className="text-center py-8 text-muted-foreground text-sm">
              Nenhum aplicativo encontrado
            </div>
          )}
        </div>

        <div className="p-3 border-t border-popover-border bg-popover/50">
          <p className="text-xs text-muted-foreground text-center">
            Hapyland OS v1.0 - Sistema Operacional Web
          </p>
          <p className="text-xs text-muted-foreground text-center mt-1">
            Desenvolvido por Kelson
          </p>
        </div>
      </div>
    </>
  );
}
