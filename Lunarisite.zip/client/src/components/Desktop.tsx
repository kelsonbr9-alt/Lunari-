import { useState, useEffect } from "react";
import { type WindowState, type AppId } from "@shared/schema";
import { Taskbar } from "./Taskbar";
import { Window } from "./Window";
import { BrowserApp } from "./apps/BrowserApp";
import { TerminalApp } from "./apps/TerminalApp";
import { FileManagerApp } from "./apps/FileManagerApp";
import { NotesApp } from "./apps/NotesApp";
import wallpaperUrl from "@assets/6f8ac66f02f13aac9e6593e859c06805_1763306898398.jpg";

const ASCII_ART = `
███╗   ██╗ █████╗ ██████╗ ██╗   ██╗██╗      █████╗ ███╗   ██╗██████╗ 
████╗  ██║██╔══██╗██╔══██╗██║   ██║██║     ██╔══██╗████╗  ██║██╔══██╗
██╔██╗ ██║███████║██████╔╝██║   ██║██║     ███████║██╔██╗ ██║██║  ██║
██║╚██╗██║██╔══██║██╔══██╗██║   ██║██║     ██╔══██║██║╚██╗██║██║  ██║
██║ ╚████║██║  ██║██║  ██║╚██████╔╝███████╗██║  ██║██║ ╚████║██████╔╝
╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝  
            HAPYLAND OS - Sistema Operacional Web
                    Desenvolvido por Kelson
`;

const STORAGE_KEY = "hapyland_windows_state";

export function Desktop() {
  const [windows, setWindows] = useState<WindowState[]>([]);
  const [highestZIndex, setHighestZIndex] = useState(100);

  useEffect(() => {
    const savedState = localStorage.getItem(STORAGE_KEY);
    if (savedState) {
      try {
        const parsed = JSON.parse(savedState);
        setWindows(parsed.windows || []);
        setHighestZIndex(parsed.highestZIndex || 100);
      } catch (error) {
        console.error("Failed to load window state:", error);
      }
    }
  }, []);

  useEffect(() => {
    if (windows.length > 0) {
      const state = {
        windows,
        highestZIndex,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    }
  }, [windows, highestZIndex]);

  const openApp = (appId: AppId) => {
    const existingWindow = windows.find(w => w.appId === appId);
    if (existingWindow) {
      if (existingWindow.isMinimized) {
        restoreWindow(existingWindow.id);
      } else {
        bringToFront(existingWindow.id);
      }
      return;
    }

    const newWindow: WindowState = {
      id: `${appId}-${Date.now()}`,
      appId,
      title: getAppTitle(appId),
      x: 80 + windows.length * 30,
      y: 60 + windows.length * 30,
      width: 800,
      height: 600,
      isMinimized: false,
      isMaximized: false,
      zIndex: highestZIndex + 1,
    };

    setWindows(prev => [...prev, newWindow]);
    setHighestZIndex(prev => prev + 1);
  };

  const closeWindow = (id: string) => {
    setWindows(prev => prev.filter(w => w.id !== id));
  };

  const minimizeWindow = (id: string) => {
    setWindows(prev =>
      prev.map(w => (w.id === id ? { ...w, isMinimized: true } : w))
    );
  };

  const maximizeWindow = (id: string) => {
    setWindows(prev =>
      prev.map(w =>
        w.id === id ? { ...w, isMaximized: !w.isMaximized } : w
      )
    );
  };

  const restoreWindow = (id: string) => {
    const newZIndex = highestZIndex + 1;
    setHighestZIndex(newZIndex);
    
    setWindows(prev =>
      prev.map(w => (w.id === id ? { ...w, isMinimized: false, zIndex: newZIndex } : w))
    );
  };

  const bringToFront = (id: string) => {
    setWindows(prev => {
      const window = prev.find(w => w.id === id);
      if (!window) return prev;

      const newZIndex = highestZIndex + 1;
      setHighestZIndex(newZIndex);

      return prev.map(w => (w.id === id ? { ...w, zIndex: newZIndex } : w));
    });
  };

  const updateWindowPosition = (id: string, x: number, y: number) => {
    setWindows(prev =>
      prev.map(w => (w.id === id ? { ...w, x, y } : w))
    );
  };

  const updateWindowSize = (id: string, width: number, height: number) => {
    setWindows(prev =>
      prev.map(w => (w.id === id ? { ...w, width, height } : w))
    );
  };

  const getAppTitle = (appId: AppId): string => {
    const titles = {
      browser: "Navegador Web",
      terminal: "Terminal",
      filemanager: "Gerenciador de Arquivos",
      notes: "Bloco de Notas",
    };
    return titles[appId];
  };

  const renderAppContent = (appId: AppId) => {
    switch (appId) {
      case "browser":
        return <BrowserApp />;
      case "terminal":
        return <TerminalApp />;
      case "filemanager":
        return <FileManagerApp />;
      case "notes":
        return <NotesApp />;
      default:
        return null;
    }
  };

  return (
    <div
      className="relative w-screen h-screen overflow-hidden bg-cover bg-center"
      style={{
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url(${wallpaperUrl})`,
      }}
      data-testid="desktop-container"
    >
      <pre
        className="absolute top-8 left-8 text-primary text-xs font-mono font-bold leading-tight opacity-90 pointer-events-none select-none"
        data-testid="ascii-art"
      >
        {ASCII_ART}
      </pre>

      {windows.map(window => (
        <Window
          key={window.id}
          window={window}
          onClose={() => closeWindow(window.id)}
          onMinimize={() => minimizeWindow(window.id)}
          onMaximize={() => maximizeWindow(window.id)}
          onFocus={() => bringToFront(window.id)}
          onPositionChange={(x, y) => updateWindowPosition(window.id, x, y)}
          onSizeChange={(width, height) =>
            updateWindowSize(window.id, width, height)
          }
        >
          {renderAppContent(window.appId)}
        </Window>
      ))}

      <Taskbar
        windows={windows}
        onAppLaunch={openApp}
        onWindowRestore={restoreWindow}
      />
    </div>
  );
}
