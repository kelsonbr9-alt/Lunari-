import { useState, useEffect } from "react";
import { type WindowState, type AppId } from "@shared/schema";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import {
  Globe,
  Terminal,
  FolderOpen,
  FileText,
  Menu,
  Cpu,
  HardDrive,
  Clock,
} from "lucide-react";
import { StartMenu } from "./StartMenu";
import { useQuery } from "@tanstack/react-query";

interface TaskbarProps {
  windows: WindowState[];
  onAppLaunch: (appId: AppId) => void;
  onWindowRestore: (id: string) => void;
}

export function Taskbar({
  windows,
  onAppLaunch,
  onWindowRestore,
}: TaskbarProps) {
  const [showStartMenu, setShowStartMenu] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  const { data: metrics } = useQuery({
    queryKey: ["/api/system/metrics"],
    refetchInterval: 2000,
  });

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const getAppIcon = (appId: AppId) => {
    switch (appId) {
      case "browser":
        return <Globe className="h-4 w-4" />;
      case "terminal":
        return <Terminal className="h-4 w-4" />;
      case "filemanager":
        return <FolderOpen className="h-4 w-4" />;
      case "notes":
        return <FileText className="h-4 w-4" />;
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  return (
    <>
      <div
        className="absolute bottom-0 left-0 right-0 h-12 bg-sidebar/95 backdrop-blur-md border-t border-sidebar-border flex items-center justify-between px-2 gap-2"
        data-testid="taskbar"
      >
        <Button
          variant="ghost"
          size="icon"
          className="h-10 w-12"
          onClick={() => setShowStartMenu(!showStartMenu)}
          data-testid="button-start-menu"
        >
          <Menu className="h-5 w-5" />
        </Button>

        <div className="flex items-center gap-2 flex-1 overflow-x-auto">
          {windows
            .filter(w => !w.isMinimized)
            .map(window => (
              <Button
                key={window.id}
                variant="secondary"
                size="sm"
                className="h-8 gap-2 min-w-[120px] max-w-[200px]"
                onClick={() => onWindowRestore(window.id)}
                data-testid={`taskbar-window-${window.appId}`}
              >
                {getAppIcon(window.appId)}
                <span className="truncate text-xs">{window.title}</span>
              </Button>
            ))}
        </div>

        <div className="flex items-center gap-4 text-xs text-sidebar-foreground">
          <div className="flex items-center gap-2">
            <Cpu className="h-4 w-4" />
            <span data-testid="cpu-metric">
              {metrics?.cpu !== undefined ? `${Math.round(metrics.cpu)}%` : "0%"}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <HardDrive className="h-4 w-4" />
            <span data-testid="memory-metric">
              {metrics?.memory !== undefined
                ? `${Math.round(metrics.memory)}%`
                : "0%"}
            </span>
          </div>

          <div className="flex flex-col items-end">
            <div className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              <span className="font-mono" data-testid="clock">
                {formatTime(currentTime)}
              </span>
            </div>
            <span className="text-[10px] text-muted-foreground" data-testid="date">
              {formatDate(currentTime)}
            </span>
          </div>
        </div>
      </div>

      {showStartMenu && (
        <StartMenu
          onAppLaunch={(appId) => {
            onAppLaunch(appId);
            setShowStartMenu(false);
          }}
          onClose={() => setShowStartMenu(false)}
        />
      )}
    </>
  );
}
