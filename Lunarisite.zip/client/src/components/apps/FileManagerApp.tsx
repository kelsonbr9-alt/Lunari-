import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { ScrollArea } from "../ui/scroll-area";
import { Skeleton } from "../ui/skeleton";
import {
  Folder,
  File,
  Plus,
  Trash2,
  ChevronRight,
  Home,
  FolderPlus,
  FilePlus,
  Loader2,
} from "lucide-react";
import { type FileNode } from "@shared/schema";

export function FileManagerApp() {
  const [currentPath, setCurrentPath] = useState("/home");
  const [selectedFile, setSelectedFile] = useState<string | null>(null);

  const { data: files, isLoading } = useQuery<FileNode[]>({
    queryKey: ["/api/files"],
  });

  const getCurrentFolder = (): FileNode | undefined => {
    if (!files) return undefined;
    
    const findFolder = (nodes: FileNode[], path: string): FileNode | undefined => {
      for (const node of nodes) {
        if (node.path === path) return node;
        if (node.children) {
          const found = findFolder(node.children, path);
          if (found) return found;
        }
      }
      return undefined;
    };
    return findFolder(files, currentPath);
  };

  const currentFolder = getCurrentFolder();
  const pathParts = currentPath.split("/").filter(Boolean);

  const navigateTo = (path: string) => {
    setCurrentPath(path);
    setSelectedFile(null);
  };

  const handleFileClick = (file: FileNode) => {
    if (file.type === "folder") {
      navigateTo(file.path);
    } else {
      setSelectedFile(file.id);
    }
  };

  const formatSize = (bytes?: number): string => {
    if (!bytes) return "0 B";
    const units = ["B", "KB", "MB", "GB"];
    let size = bytes;
    let unitIndex = 0;
    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }
    return `${size.toFixed(1)} ${units[unitIndex]}`;
  };

  const formatDate = (date?: Date): string => {
    if (!date) return "-";
    return new Date(date).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="p-3 border-b border-border bg-sidebar flex items-center gap-2">
        <Button
          size="icon"
          variant="ghost"
          className="h-8 w-8"
          onClick={() => navigateTo("/home")}
          data-testid="button-home"
        >
          <Home className="h-4 w-4" />
        </Button>

        <div className="flex items-center gap-1 flex-1 overflow-x-auto text-sm">
          <Button
            size="sm"
            variant="ghost"
            className="h-7 px-2"
            onClick={() => navigateTo("/home")}
            data-testid="breadcrumb-home"
          >
            home
          </Button>
          {pathParts.slice(1).map((part, index) => {
            const path = "/" + pathParts.slice(0, index + 2).join("/");
            return (
              <div key={path} className="flex items-center gap-1">
                <ChevronRight className="h-3 w-3 text-muted-foreground" />
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7 px-2"
                  onClick={() => navigateTo(path)}
                  data-testid={`breadcrumb-${part}`}
                >
                  {part}
                </Button>
              </div>
            );
          })}
        </div>

        <div className="flex items-center gap-1">
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8"
            data-testid="button-new-folder"
          >
            <FolderPlus className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8"
            data-testid="button-new-file"
          >
            <FilePlus className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <ScrollArea className="flex-1">
        {isLoading ? (
          <div className="p-4 space-y-2">
            <div className="flex items-center gap-4 text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span className="text-sm">Carregando arquivos...</span>
            </div>
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="flex items-center gap-4 px-4 py-2">
                <Skeleton className="h-5 w-5" />
                <Skeleton className="h-4 flex-1" />
                <Skeleton className="h-4 w-20" />
                <Skeleton className="h-4 w-32" />
              </div>
            ))}
          </div>
        ) : (
          <div className="p-4">
            <div className="space-y-1">
              <div className="grid grid-cols-[auto_1fr_100px_150px] gap-4 px-4 py-2 text-xs font-semibold text-muted-foreground border-b border-border">
                <div className="w-8"></div>
                <div>Nome</div>
                <div>Tamanho</div>
                <div>Modificado</div>
              </div>

              {currentFolder?.children?.map(file => (
                <div
                  key={file.id}
                  className={`grid grid-cols-[auto_1fr_100px_150px] gap-4 px-4 py-2 rounded-md cursor-pointer hover-elevate active-elevate-2 ${
                    selectedFile === file.id ? "bg-accent" : ""
                  }`}
                  onClick={() => handleFileClick(file)}
                  data-testid={`file-item-${file.name}`}
                >
                  <div className="w-8 flex items-center">
                    {file.type === "folder" ? (
                      <Folder className="h-5 w-5 text-primary" />
                    ) : (
                      <File className="h-5 w-5 text-foreground" />
                    )}
                  </div>
                  <div className="text-sm truncate">{file.name}</div>
                  <div className="text-sm text-muted-foreground">
                    {file.type === "folder" ? "-" : formatSize(file.size)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {formatDate(file.modified)}
                  </div>
                </div>
              ))}

              {(!currentFolder?.children || currentFolder.children.length === 0) && (
                <div className="text-center py-12 text-muted-foreground">
                  Esta pasta está vazia
                </div>
              )}
            </div>
          </div>
        )}
      </ScrollArea>
    </div>
  );
}
