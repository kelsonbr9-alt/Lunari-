import { useState, useEffect, useRef } from "react";
import { ScrollArea } from "../ui/scroll-area";
import { Badge } from "../ui/badge";
import { Loader2 } from "lucide-react";

interface TerminalLine {
  type: "input" | "output" | "error" | "system";
  content: string;
  timestamp: number;
}

export function TerminalApp() {
  const [lines, setLines] = useState<TerminalLine[]>([]);
  const [currentInput, setCurrentInput] = useState("");
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      setIsConnected(true);
      setIsConnecting(false);
      addLine({
        type: "system",
        content: "✓ Conectado ao servidor terminal",
        timestamp: Date.now(),
      });
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === "clear") {
          setLines([]);
          return;
        }

        addLine({
          type: data.type || "output",
          content: data.content,
          timestamp: data.timestamp || Date.now(),
        });
      } catch (error) {
        console.error("Terminal message error:", error);
      }
    };

    ws.onerror = (error) => {
      console.error("Terminal WebSocket error:", error);
      setIsConnecting(false);
      setIsConnected(false);
      addLine({
        type: "error",
        content: "✗ Erro de conexão com o servidor",
        timestamp: Date.now(),
      });
    };

    ws.onclose = () => {
      setIsConnected(false);
      setIsConnecting(false);
      addLine({
        type: "system",
        content: "✗ Desconectado do servidor",
        timestamp: Date.now(),
      });
    };

    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
    };
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [lines]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const addLine = (line: TerminalLine) => {
    setLines(prev => [...prev, line]);
  };

  const executeCommand = (command: string) => {
    const trimmedCommand = command.trim();
    if (!trimmedCommand) return;

    setCommandHistory(prev => [...prev, trimmedCommand]);
    setHistoryIndex(-1);

    addLine({
      type: "input",
      content: `$ ${trimmedCommand}`,
      timestamp: Date.now(),
    });

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(
        JSON.stringify({
          type: "command",
          content: trimmedCommand,
        })
      );
    } else {
      addLine({
        type: "error",
        content: "✗ Não conectado ao servidor",
        timestamp: Date.now(),
      });
    }

    setCurrentInput("");
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      executeCommand(currentInput);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (commandHistory.length > 0) {
        const newIndex =
          historyIndex === -1
            ? commandHistory.length - 1
            : Math.max(0, historyIndex - 1);
        setHistoryIndex(newIndex);
        setCurrentInput(commandHistory[newIndex]);
      }
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      if (historyIndex !== -1) {
        const newIndex = historyIndex + 1;
        if (newIndex >= commandHistory.length) {
          setHistoryIndex(-1);
          setCurrentInput("");
        } else {
          setHistoryIndex(newIndex);
          setCurrentInput(commandHistory[newIndex]);
        }
      }
    }
  };

  return (
    <div
      className="h-full bg-background p-4 font-mono text-sm overflow-hidden flex flex-col"
      onClick={() => inputRef.current?.focus()}
    >
      <div className="flex items-center justify-between mb-2 pb-2 border-b border-border">
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Terminal WebSocket</span>
          {isConnecting && (
            <Badge variant="secondary" className="gap-1">
              <Loader2 className="h-3 w-3 animate-spin" />
              Conectando...
            </Badge>
          )}
          {!isConnecting && isConnected && (
            <Badge variant="default" className="bg-green-600">
              ✓ Conectado
            </Badge>
          )}
          {!isConnecting && !isConnected && (
            <Badge variant="destructive">
              ✗ Desconectado
            </Badge>
          )}
        </div>
      </div>

      <ScrollArea className="flex-1" ref={scrollRef}>
        <div className="space-y-1">
          {lines.map((line, index) => (
            <div
              key={`${line.timestamp}-${index}`}
              className={
                line.type === "input"
                  ? "text-primary font-semibold"
                  : line.type === "error"
                  ? "text-destructive"
                  : line.type === "system"
                  ? "text-accent-foreground italic"
                  : "text-foreground"
              }
              data-testid={`terminal-line-${index}`}
            >
              {line.content}
            </div>
          ))}
        </div>
      </ScrollArea>

      <div className="flex items-center gap-2 mt-2 pt-2 border-t border-border">
        <span className="text-primary font-semibold">$</span>
        <input
          ref={inputRef}
          type="text"
          value={currentInput}
          onChange={(e) => setCurrentInput(e.target.value)}
          onKeyDown={handleKeyDown}
          className="flex-1 bg-transparent outline-none text-foreground disabled:opacity-50"
          spellCheck={false}
          autoComplete="off"
          disabled={!isConnected}
          placeholder={isConnected ? "Digite um comando..." : "Aguardando conexão..."}
          data-testid="input-terminal"
        />
      </div>
    </div>
  );
}
