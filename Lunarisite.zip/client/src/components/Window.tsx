import { useState, useRef, useEffect, type ReactNode } from "react";
import { type WindowState } from "@shared/schema";
import { Button } from "./ui/button";
import { Minus, Maximize2, Minimize2, X } from "lucide-react";

interface WindowProps {
  window: WindowState;
  children: ReactNode;
  onClose: () => void;
  onMinimize: () => void;
  onMaximize: () => void;
  onFocus: () => void;
  onPositionChange: (x: number, y: number) => void;
  onSizeChange: (width: number, height: number) => void;
}

export function Window({
  window,
  children,
  onClose,
  onMinimize,
  onMaximize,
  onFocus,
  onPositionChange,
  onSizeChange,
}: WindowProps) {
  const windowRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [resizeDirection, setResizeDirection] = useState<string | null>(null);

  useEffect(() => {
    if (!isDragging && !isResizing) return;

    const handleMouseMove = (e: MouseEvent) => {
      if (window.isMaximized) return;

      if (isDragging) {
        const newX = e.clientX - dragOffset.x;
        const newY = e.clientY - dragOffset.y;
        onPositionChange(Math.max(0, newX), Math.max(0, newY));
      }

      if (isResizing && resizeDirection) {
        const rect = windowRef.current?.getBoundingClientRect();
        if (!rect) return;

        let newWidth = window.width;
        let newHeight = window.height;
        let newX = window.x;
        let newY = window.y;

        if (resizeDirection.includes("e")) {
          newWidth = Math.max(400, e.clientX - rect.left);
        }
        if (resizeDirection.includes("s")) {
          newHeight = Math.max(300, e.clientY - rect.top);
        }
        if (resizeDirection.includes("w")) {
          const delta = e.clientX - rect.left;
          newWidth = Math.max(400, rect.width - delta);
          newX = rect.left + delta;
        }
        if (resizeDirection.includes("n")) {
          const delta = e.clientY - rect.top;
          newHeight = Math.max(300, rect.height - delta);
          newY = rect.top + delta;
        }

        onSizeChange(newWidth, newHeight);
        if (newX !== window.x || newY !== window.y) {
          onPositionChange(newX, newY);
        }
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      setIsResizing(false);
      setResizeDirection(null);
    };

    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);

    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isDragging, isResizing, dragOffset, resizeDirection, window, onPositionChange, onSizeChange]);

  const handleTitleBarMouseDown = (e: React.MouseEvent) => {
    if (window.isMaximized) return;
    const rect = windowRef.current?.getBoundingClientRect();
    if (!rect) return;

    setDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
    setIsDragging(true);
    onFocus();
  };

  const handleResizeStart = (direction: string) => (e: React.MouseEvent) => {
    e.stopPropagation();
    setResizeDirection(direction);
    setIsResizing(true);
    onFocus();
  };

  if (window.isMinimized) return null;

  const style = window.isMaximized
    ? { left: 0, top: 0, width: "100%", height: "calc(100% - 3rem)" }
    : { left: window.x, top: window.y, width: window.width, height: window.height };

  return (
    <div
      ref={windowRef}
      className="absolute bg-card border-2 border-card-border rounded-lg overflow-hidden flex flex-col"
      style={{ ...style, zIndex: window.zIndex }}
      onMouseDown={onFocus}
      data-testid={`window-${window.appId}`}
    >
      <div
        className="h-8 bg-sidebar border-b border-sidebar-border flex items-center justify-between px-2 cursor-move select-none backdrop-blur-sm"
        onMouseDown={handleTitleBarMouseDown}
        data-testid={`window-titlebar-${window.appId}`}
      >
        <span className="text-sm font-semibold text-sidebar-foreground truncate flex-1">
          {window.title}
        </span>
        <div className="flex items-center gap-1">
          <Button
            size="icon"
            variant="ghost"
            className="h-6 w-6"
            onClick={(e) => {
              e.stopPropagation();
              onMinimize();
            }}
            data-testid={`button-minimize-${window.appId}`}
          >
            <Minus className="h-3 w-3" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-6 w-6"
            onClick={(e) => {
              e.stopPropagation();
              onMaximize();
            }}
            data-testid={`button-maximize-${window.appId}`}
          >
            {window.isMaximized ? (
              <Minimize2 className="h-3 w-3" />
            ) : (
              <Maximize2 className="h-3 w-3" />
            )}
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-6 w-6 hover:bg-destructive hover:text-destructive-foreground"
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            data-testid={`button-close-${window.appId}`}
          >
            <X className="h-3 w-3" />
          </Button>
        </div>
      </div>

      <div className="flex-1 overflow-hidden bg-background">
        {children}
      </div>

      {!window.isMaximized && (
        <>
          <div
            className="absolute top-0 left-0 right-0 h-1 cursor-n-resize"
            onMouseDown={handleResizeStart("n")}
          />
          <div
            className="absolute bottom-0 left-0 right-0 h-1 cursor-s-resize"
            onMouseDown={handleResizeStart("s")}
          />
          <div
            className="absolute top-0 bottom-0 left-0 w-1 cursor-w-resize"
            onMouseDown={handleResizeStart("w")}
          />
          <div
            className="absolute top-0 bottom-0 right-0 w-1 cursor-e-resize"
            onMouseDown={handleResizeStart("e")}
          />
          <div
            className="absolute top-0 left-0 w-2 h-2 cursor-nw-resize"
            onMouseDown={handleResizeStart("nw")}
          />
          <div
            className="absolute top-0 right-0 w-2 h-2 cursor-ne-resize"
            onMouseDown={handleResizeStart("ne")}
          />
          <div
            className="absolute bottom-0 left-0 w-2 h-2 cursor-sw-resize"
            onMouseDown={handleResizeStart("sw")}
          />
          <div
            className="absolute bottom-0 right-0 w-2 h-2 cursor-se-resize"
            onMouseDown={handleResizeStart("se")}
          />
        </>
      )}
    </div>
  );
}
