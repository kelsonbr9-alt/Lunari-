import { z } from "zod";

// Sistema de arquivos virtual
export interface FileNode {
  id: string;
  name: string;
  type: "file" | "folder";
  path: string;
  content?: string;
  children?: FileNode[];
  size?: number;
  modified?: Date;
}

export const insertFileSchema = z.object({
  name: z.string().min(1),
  type: z.enum(["file", "folder"]),
  content: z.string().optional(),
});

export type InsertFile = z.infer<typeof insertFileSchema>;

// Métricas do sistema
export interface SystemMetrics {
  cpu: number;
  memory: number;
  timestamp: number;
}

// Estado de janela
export interface WindowState {
  id: string;
  appId: string;
  title: string;
  x: number;
  y: number;
  width: number;
  height: number;
  isMinimized: boolean;
  isMaximized: boolean;
  zIndex: number;
}

// Aplicativos disponíveis
export type AppId = "browser" | "terminal" | "filemanager" | "notes";

export interface AppDefinition {
  id: AppId;
  name: string;
  icon: string;
  description: string;
}

// Terminal
export interface TerminalMessage {
  type: "input" | "output" | "error";
  content: string;
  timestamp: number;
}

// Histórico de comandos do terminal
export interface CommandHistory {
  command: string;
  timestamp: number;
  output?: string;
}
