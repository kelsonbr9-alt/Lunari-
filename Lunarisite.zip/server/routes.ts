import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertFileSchema } from "@shared/schema";

const ALLOWED_COMMANDS = [
  "help",
  "ls",
  "pwd",
  "whoami",
  "date",
  "echo",
  "uname",
  "hostname",
  "uptime",
  "clear",
  "history",
];

const commandRateLimits = new Map<string, { count: number; resetAt: number }>();
const MAX_COMMANDS_PER_MINUTE = 30;

function checkRateLimit(clientId: string): boolean {
  const now = Date.now();
  const limit = commandRateLimits.get(clientId);

  if (!limit || now > limit.resetAt) {
    commandRateLimits.set(clientId, {
      count: 1,
      resetAt: now + 60000,
    });
    return true;
  }

  if (limit.count >= MAX_COMMANDS_PER_MINUTE) {
    return false;
  }

  limit.count++;
  return true;
}

function isCommandAllowed(command: string): boolean {
  const parts = command.trim().split(/\s+/);
  const cmd = parts[0].toLowerCase();
  return ALLOWED_COMMANDS.includes(cmd);
}

function executeSimulatedCommand(command: string): { stdout?: string; stderr?: string } {
  const parts = command.trim().split(/\s+/);
  const cmd = parts[0].toLowerCase();

  switch (cmd) {
    case "help":
      return {
        stdout: `Comandos disponíveis:
  help       - Mostra esta mensagem
  ls         - Lista arquivos (simulado)
  pwd        - Mostra diretório atual
  whoami     - Mostra usuário
  date       - Mostra data/hora
  echo       - Ecoa texto
  uname      - Info do sistema
  hostname   - Nome do host
  uptime     - Tempo ativo
  clear      - Limpa tela
  history    - Histórico de comandos`,
      };

    case "ls":
      return {
        stdout: "Documentos  Downloads  Imagens",
      };

    case "pwd":
      return {
        stdout: "/home/hapyland",
      };

    case "whoami":
      return {
        stdout: "hapyland-user",
      };

    case "date":
      return {
        stdout: new Date().toLocaleString("pt-BR"),
      };

    case "echo":
      return {
        stdout: parts.slice(1).join(" "),
      };

    case "uname":
      return {
        stdout: "Hapyland OS 1.0 (WebOS) - Desenvolvido por Kelson",
      };

    case "hostname":
      return {
        stdout: "hapyland-os",
      };

    case "uptime":
      return {
        stdout: "Sistema ativo desde: " + new Date(Date.now() - Math.random() * 3600000).toLocaleString("pt-BR"),
      };

    default:
      return {
        stderr: `bash: ${cmd}: comando não encontrado\nDigite 'help' para ver comandos disponíveis`,
      };
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/system/metrics", async (_req, res) => {
    try {
      const metrics = await storage.getSystemMetrics();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to get system metrics" });
    }
  });

  app.get("/api/files", async (_req, res) => {
    try {
      const files = await storage.getFiles();
      res.json(files);
    } catch (error) {
      res.status(500).json({ error: "Failed to get files" });
    }
  });

  app.post("/api/files", async (req, res) => {
    try {
      const { parentPath, ...fileData } = req.body;
      
      if (!parentPath || typeof parentPath !== "string") {
        return res.status(400).json({ error: "parentPath is required" });
      }

      const result = insertFileSchema.safeParse(fileData);
      if (!result.success) {
        return res.status(400).json({ error: "Invalid file data", details: result.error });
      }

      const file = await storage.createFile(parentPath, result.data);
      res.json(file);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to create file" });
    }
  });

  app.put("/api/files/:path(*)", async (req, res) => {
    try {
      const path = "/" + req.params.path;
      const { content } = req.body;

      if (typeof content !== "string") {
        return res.status(400).json({ error: "Content must be a string" });
      }

      if (!path.startsWith("/")) {
        return res.status(400).json({ error: "Invalid path" });
      }

      const file = await storage.updateFile(path, content);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }

      res.json(file);
    } catch (error) {
      res.status(500).json({ error: "Failed to update file" });
    }
  });

  app.delete("/api/files/:path(*)", async (req, res) => {
    try {
      const path = "/" + req.params.path;

      if (!path.startsWith("/")) {
        return res.status(400).json({ error: "Invalid path" });
      }

      const success = await storage.deleteFile(path);
      if (!success) {
        return res.status(404).json({ error: "File not found" });
      }

      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to delete file" });
    }
  });

  const httpServer = createServer(app);

  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  wss.on("connection", (ws: WebSocket, req) => {
    const clientId = req.socket.remoteAddress + ":" + req.socket.remotePort;
    console.log("Terminal WebSocket client connected:", clientId);

    ws.send(
      JSON.stringify({
        type: "output",
        content: "Hapyland OS Terminal v1.0 - Desenvolvido por Kelson",
        timestamp: Date.now(),
      })
    );

    ws.send(
      JSON.stringify({
        type: "output",
        content: "Terminal simulado seguro (comandos limitados)",
        timestamp: Date.now() + 1,
      })
    );

    ws.send(
      JSON.stringify({
        type: "output",
        content: "Digite 'help' para ver comandos disponíveis",
        timestamp: Date.now() + 2,
      })
    );

    ws.on("message", async (message: Buffer) => {
      try {
        if (!checkRateLimit(clientId)) {
          ws.send(
            JSON.stringify({
              type: "error",
              content: "Rate limit excedido. Aguarde um momento antes de enviar mais comandos.",
              timestamp: Date.now(),
            })
          );
          return;
        }

        const data = JSON.parse(message.toString());

        if (data.type === "command") {
          const command = data.content.trim();

          if (command === "clear") {
            ws.send(
              JSON.stringify({
                type: "clear",
                timestamp: Date.now(),
              })
            );
            return;
          }

          if (!isCommandAllowed(command)) {
            ws.send(
              JSON.stringify({
                type: "error",
                content: `Comando não permitido: ${command.split(/\s+/)[0]}\nDigite 'help' para ver comandos disponíveis`,
                timestamp: Date.now(),
              })
            );
            return;
          }

          const result = executeSimulatedCommand(command);

          if (result.stdout) {
            ws.send(
              JSON.stringify({
                type: "output",
                content: result.stdout,
                timestamp: Date.now(),
              })
            );
          }

          if (result.stderr) {
            ws.send(
              JSON.stringify({
                type: "error",
                content: result.stderr,
                timestamp: Date.now(),
              })
            );
          }
        }
      } catch (error) {
        console.error("WebSocket message error:", error);
        ws.send(
          JSON.stringify({
            type: "error",
            content: "Erro ao processar comando",
            timestamp: Date.now(),
          })
        );
      }
    });

    ws.on("close", () => {
      console.log("Terminal WebSocket client disconnected:", clientId);
      commandRateLimits.delete(clientId);
    });

    ws.on("error", (error) => {
      console.error("WebSocket error:", error);
    });
  });

  return httpServer;
}
