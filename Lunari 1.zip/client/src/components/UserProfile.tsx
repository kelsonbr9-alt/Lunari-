import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import profileImage from "@assets/images_1757753626285.jpeg";

interface UserProfileProps {
  displayName: string;
  bio?: string | null;
  avatar?: string | null;
  className?: string;
}

export default function UserProfile({ displayName, bio, avatar, className = "" }: UserProfileProps) {
  // Se o avatar começa com @assets/, usar a imagem importada
  const avatarSrc = avatar?.startsWith('@assets/images_1757753626285.jpeg') ? profileImage : avatar || "";
  
  return (
    <div className={`flex flex-col items-center text-center space-y-4 ${className}`}>
      <Avatar className="w-32 h-32 border-4 border-white/20 shadow-2xl">
        <AvatarImage src={avatarSrc} alt={displayName} />
        <AvatarFallback className="text-2xl font-bold bg-gradient-to-br from-purple-400 to-pink-400 text-white">
          {displayName.charAt(0).toUpperCase()}
        </AvatarFallback>
      </Avatar>
      
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-white drop-shadow-lg">
          {displayName}
        </h1>
        {bio && (
          <p className="text-white/90 text-lg max-w-md mx-auto drop-shadow-md">
            {bio}
          </p>
        )}
      </div>
    </div>
  );
}