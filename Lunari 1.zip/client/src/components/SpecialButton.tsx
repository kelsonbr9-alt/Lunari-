import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

interface SpecialButtonProps {
  title: string;
  url: string;
  description?: string;
  className?: string;
}

export default function SpecialButton({ title, url, description, className = "" }: SpecialButtonProps) {
  const handleClick = () => {
    console.log(`Abrindo link especial: ${url}`);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className={`w-full max-w-sm mx-auto ${className}`}>
      <Button
        onClick={handleClick}
        size="lg"
        className="w-full h-16 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:from-indigo-600 hover:via-purple-600 hover:to-pink-600 text-white font-bold text-lg shadow-2xl border-2 border-white/20 transition-all duration-300 hover:scale-105 hover:shadow-purple-500/25"
        data-testid="button-special-link"
      >
        <div className="flex items-center space-x-3">
          <span>{title}</span>
          <ExternalLink className="h-5 w-5" />
        </div>
      </Button>
      {description && (
        <p className="text-white/80 text-sm text-center mt-2 drop-shadow-md">
          {description}
        </p>
      )}
    </div>
  );
}