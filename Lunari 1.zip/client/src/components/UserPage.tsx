import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import BackgroundVideo from "./BackgroundVideo";
import UserProfile from "./UserProfile";
import SpecialButton from "./SpecialButton";
import LinkGrid from "./LinkGrid";
import FullscreenToggle from "./FullscreenToggle";
import { useFullscreen } from "@/hooks/useFullscreen";
import type { User, Link } from "@shared/schema";

interface UserPageProps {
  username: string;
}

interface UserData {
  user: User;
  links: Link[];
}

export default function UserPage({ username }: UserPageProps) {
  const { data, isLoading, error } = useQuery<UserData>({
    queryKey: ['/api/users', username],
    enabled: !!username,
  });

  const { enterFullscreen } = useFullscreen();

  // Ativar tela cheia automaticamente quando entrar na página do usuário
  useEffect(() => {
    const timer = setTimeout(() => {
      enterFullscreen();
    }, 1000);

    return () => clearTimeout(timer);
  }, [enterFullscreen]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <BackgroundVideo />
        <div className="relative z-10 text-white text-xl">
          Carregando...
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <BackgroundVideo />
        <div className="relative z-10 text-center text-white">
          <h1 className="text-2xl font-bold mb-4">Usuário não encontrado</h1>
          <p className="text-white/80">Verifique se o link está correto</p>
        </div>
      </div>
    );
  }

  const { user, links } = data;

  return (
    <div className="min-h-screen relative">
      <BackgroundVideo />
      <FullscreenToggle />
      
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-8 space-y-8">
        <UserProfile
          displayName={user.displayName}
          bio={user.bio}
          avatar={user.avatar}
        />

        <SpecialButton
          title="Entrar no Discord"
          url="https://discord.gg/D3RrAfe4mm"
          description="Junte-se à nossa comunidade!"
        />

        <LinkGrid links={links} />
      </div>
    </div>
  );
}