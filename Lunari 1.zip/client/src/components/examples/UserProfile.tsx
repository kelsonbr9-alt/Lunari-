import UserProfile from '../UserProfile';

export default function UserProfileExample() {
  return (
    <div className="p-8">
      <UserProfile 
        displayName="Usuário Demo"
        bio="Criador de conteúdo digital"
        avatar=""
      />
    </div>
  );
}