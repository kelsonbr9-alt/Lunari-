import SpecialButton from '../SpecialButton';

export default function SpecialButtonExample() {
  return (
    <div className="p-8">
      <SpecialButton 
        title="Entrar no Discord"
        url="https://discord.gg/D3RrAfe4mm"
        description="Junte-se à nossa comunidade!"
      />
    </div>
  );
}