import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import UserPage from '../UserPage';

// todo: remove mock functionality
const mockQueryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
    },
  },
});

// todo: remove mock functionality - Mock the API response
mockQueryClient.setQueryData(['/api/users', 'usuario_demo'], {
  user: {
    id: "sample-user-1",
    username: "usuario_demo",
    displayName: "Usuário Demo",
    bio: "Criador de conteúdo digital",
    avatar: null,
    theme: "default",
    isPublic: true,
  },
  links: [
    {
      id: "link-1",
      userId: "sample-user-1",
      title: "Meu Site",
      url: "https://meusite.com",
      description: "Site pessoal com portfólio",
      icon: "🌐",
      isActive: true,
      order: "1",
      createdAt: new Date(),
    },
    {
      id: "link-2",
      userId: "sample-user-1",
      title: "Instagram",
      url: "https://instagram.com/usuario",
      description: "Siga-me no Instagram",
      icon: "📸",
      isActive: true,
      order: "2",
      createdAt: new Date(),
    },
    {
      id: "link-3",
      userId: "sample-user-1",
      title: "YouTube",
      url: "https://youtube.com/channel/usuario",
      description: "Canal no YouTube",
      icon: "🎥",
      isActive: true,
      order: "3",
      createdAt: new Date(),
    },
  ],
});

export default function UserPageExample() {
  return (
    <QueryClientProvider client={mockQueryClient}>
      <UserPage username="usuario_demo" />
    </QueryClientProvider>
  );
}