import BackgroundVideo from '../BackgroundVideo';

export default function BackgroundVideoExample() {
  return <BackgroundVideo />;
}