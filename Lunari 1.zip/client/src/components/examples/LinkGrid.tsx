import LinkGrid from '../LinkGrid';
import type { Link } from "@shared/schema";

export default function LinkGridExample() {
  // todo: remove mock functionality
  const mockLinks: Link[] = [
    {
      id: "1",
      userId: "user1",
      title: "Meu Site",
      url: "https://meusite.com",
      description: "Site pessoal com portfólio",
      icon: "🌐",
      isActive: true,
      order: "1",
      createdAt: new Date(),
    },
    {
      id: "2",
      userId: "user1",
      title: "Instagram",
      url: "https://instagram.com/usuario",
      description: "Siga-me no Instagram",
      icon: "📸",
      isActive: true,
      order: "2",
      createdAt: new Date(),
    },
    {
      id: "3",
      userId: "user1",
      title: "YouTube",
      url: "https://youtube.com/channel/usuario",
      description: "Canal no YouTube",
      icon: "🎥",
      isActive: true,
      order: "3",
      createdAt: new Date(),
    },
  ];

  return (
    <div className="p-8">
      <LinkGrid links={mockLinks} />
    </div>
  );
}