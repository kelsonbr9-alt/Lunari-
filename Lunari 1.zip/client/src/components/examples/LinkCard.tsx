import LinkCard from '../LinkCard';

export default function LinkCardExample() {
  return (
    <div className="p-8 space-y-4">
      <LinkCard 
        title="Meu Site"
        url="https://meusite.com"
        description="Site pessoal com portfólio"
        icon="🌐"
      />
      <LinkCard 
        title="Instagram"
        url="https://instagram.com/usuario"
        description="Siga-me no Instagram"
        icon="📸"
      />
    </div>
  );
}