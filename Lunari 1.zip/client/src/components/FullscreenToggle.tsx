import { Button } from "@/components/ui/button";
import { Maximize, Minimize } from "lucide-react";
import { useFullscreen } from "@/hooks/useFullscreen";

interface FullscreenToggleProps {
  className?: string;
}

export default function FullscreenToggle({ className = "" }: FullscreenToggleProps) {
  const { isFullscreen, toggleFullscreen } = useFullscreen();

  return (
    <Button
      onClick={toggleFullscreen}
      size="icon"
      variant="ghost"
      className={`fixed top-4 right-4 z-50 bg-black/20 backdrop-blur-sm border border-white/20 text-white hover:bg-black/40 transition-all duration-300 ${className}`}
      data-testid="button-fullscreen-toggle"
    >
      {isFullscreen ? (
        <Minimize className="h-4 w-4" />
      ) : (
        <Maximize className="h-4 w-4" />
      )}
    </Button>
  );
}