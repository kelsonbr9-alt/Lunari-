import LinkCard from "./LinkCard";
import type { Link } from "@shared/schema";

interface LinkGridProps {
  links: Link[];
  className?: string;
}

export default function LinkGrid({ links, className = "" }: LinkGridProps) {
  if (!links || links.length === 0) {
    return (
      <div className={`text-center py-8 ${className}`}>
        <p className="text-white/70 text-lg">Nenhum link ainda</p>
      </div>
    );
  }

  return (
    <div className={`space-y-4 w-full max-w-md mx-auto ${className}`}>
      {links.map((link) => (
        <LinkCard
          key={link.id}
          title={link.title}
          url={link.url}
          description={link.description}
          icon={link.icon}
        />
      ))}
    </div>
  );
}