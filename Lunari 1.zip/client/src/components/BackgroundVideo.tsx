import backgroundGif from "@assets/f72c1cc4b8d179f58fe9f7aee54d3dfc_1757753007731.gif";

interface BackgroundVideoProps {
  className?: string;
}

export default function BackgroundVideo({ className = "" }: BackgroundVideoProps) {
  return (
    <div className={`fixed inset-0 z-0 ${className}`}>
      <img
        src={backgroundGif}
        alt="Fundo espacial com estrelas e lua"
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-black/20" />
    </div>
  );
}