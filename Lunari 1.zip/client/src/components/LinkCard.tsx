import { Card } from "@/components/ui/card";
import { ExternalLink } from "lucide-react";

interface LinkCardProps {
  title: string;
  url: string;
  description?: string | null;
  icon?: string | null;
  className?: string;
}

export default function LinkCard({ title, url, description, icon, className = "" }: LinkCardProps) {
  const handleClick = () => {
    console.log(`Abrindo link: ${url}`);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <Card 
      className={`p-4 bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300 cursor-pointer hover:scale-105 hover:shadow-xl hover:shadow-purple-500/20 group ${className}`}
      onClick={handleClick}
      data-testid={`card-link-${title.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <div className="flex items-center space-x-4">
        <div className="flex-shrink-0">
          {icon ? (
            <span className="text-2xl">{icon}</span>
          ) : (
            <ExternalLink className="h-6 w-6 text-white/70" />
          )}
        </div>
        
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-white text-lg truncate group-hover:text-purple-200 transition-colors">
            {title}
          </h3>
          {description && (
            <p className="text-white/70 text-sm truncate">
              {description}
            </p>
          )}
        </div>

        <ExternalLink className="h-4 w-4 text-white/50 opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>
    </Card>
  );
}