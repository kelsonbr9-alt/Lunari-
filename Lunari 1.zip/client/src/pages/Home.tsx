import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useEffect } from "react";
import BackgroundVideo from "@/components/BackgroundVideo";
import FullscreenToggle from "@/components/FullscreenToggle";
import { useFullscreen } from "@/hooks/useFullscreen";

export default function Home() {
  const [, setLocation] = useLocation();
  const { enterFullscreen } = useFullscreen();

  // Ativar tela cheia automaticamente quando entrar na página
  useEffect(() => {
    const timer = setTimeout(() => {
      enterFullscreen();
    }, 1000); // Aguarda 1 segundo para boa experiência

    return () => clearTimeout(timer);
  }, [enterFullscreen]);

  const handleViewDemo = () => {
    console.log('Navegando para página de demo');
    setLocation('/lunari');
  };

  return (
    <div className="min-h-screen relative">
      <BackgroundVideo />
      <FullscreenToggle />
      
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-8 text-center space-y-8">
        <div className="space-y-4">
          <h1 className="text-5xl font-bold text-white drop-shadow-lg">
            Bem-vindos ao Espaço da Lunari
          </h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto drop-shadow-md">
            Explore o universo através dos meus links e conteúdos
          </p>
        </div>

        <Button
          onClick={handleViewDemo}
          size="lg"
          className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold text-lg px-8 py-4 shadow-2xl border-2 border-white/20 transition-all duration-300 hover:scale-105"
          data-testid="button-view-demo"
        >
          Entrar no Meu Espaço
        </Button>
      </div>
    </div>
  );
}