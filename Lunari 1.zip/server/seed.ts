import { db } from "./db";
import { users, links } from "@shared/schema";

async function seed() {
  try {
    console.log("🌱 Criando dados de exemplo...");

    // Criar usuário de exemplo
    const [user] = await db
      .insert(users)
      .values({
        username: "usuario_demo",
        displayName: "Usuário Demo",
        bio: "Criador de conteúdo digital",
        avatar: null,
        theme: "default",
        isPublic: true,
      })
      .returning();

    console.log("✅ Usuário criado:", user.username);

    // Criar links de exemplo
    const linksData = [
      {
        userId: user.id,
        title: "Meu Site",
        url: "https://meusite.com",
        description: "Site pessoal com portfólio",
        icon: "🌐",
        isActive: true,
        order: "1",
      },
      {
        userId: user.id,
        title: "Instagram",
        url: "https://instagram.com/usuario",
        description: "Siga-me no Instagram",
        icon: "📸",
        isActive: true,
        order: "2",
      },
      {
        userId: user.id,
        title: "YouTube",
        url: "https://youtube.com/channel/usuario",
        description: "Canal no YouTube",
        icon: "🎥",
        isActive: true,
        order: "3",
      },
    ];

    for (const linkData of linksData) {
      const [link] = await db
        .insert(links)
        .values(linkData)
        .returning();
      console.log("✅ Link criado:", link.title);
    }

    console.log("🎉 Dados de exemplo criados com sucesso!");
  } catch (error) {
    console.error("❌ Erro ao criar dados de exemplo:", error);
  }
}

seed();