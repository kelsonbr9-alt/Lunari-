# Hapyland OS - Design Guidelines

## Design Approach

**Reference-Based + System Hybrid**: Inspired by modern desktop operating systems (Windows 11, macOS Big Sur, KDE Plasma) with cyberpunk/dark aesthetic. Focus on familiar OS patterns with futuristic visual treatment.

## Core Design Principles

1. **Desktop OS Authenticity**: Replicate real operating system patterns (taskbar, window chrome, start menu)
2. **Spatial Depth**: Layered interface with clear z-axis hierarchy (desktop → windows → modals)
3. **Functional Density**: Information-rich displays without clutter (system widgets, file listings, terminal output)

## Typography

**Font Stack**:
- **System/UI**: "Inter", "SF Pro Display", system-ui, sans-serif (crisp, modern OS feel)
- **Monospace**: "JetBrains Mono", "Fira Code", "Consolas", monospace (terminal, code editor)

**Hierarchy**:
- Window titles: 14px, font-weight-600
- Body text: 13px, font-weight-400
- Terminal/code: 13px, font-weight-400, monospace
- System widgets: 12px, font-weight-500
- Menu items: 13px, font-weight-400
- ASCII art: 10-12px, monospace, font-weight-700

## Layout System

**Spacing Units**: Use Tailwind units of **2, 3, 4, 6, 8** consistently
- Window padding: p-4
- Taskbar height: h-12
- Widget spacing: gap-4
- Menu item padding: px-4 py-2
- Button spacing: px-6 py-2

**Grid System**:
- Desktop: Full viewport (w-screen h-screen)
- Window positioning: Absolute positioning with drag constraints
- Taskbar: Fixed bottom, full width
- Start menu: Absolute bottom-12 left-0, width 320px

## Component Library

### Desktop Shell

**Desktop Background**:
- Full viewport container with wallpaper background
- ASCII art positioned top-8 left-8 as permanent overlay
- Interactive area for desktop icons (grid layout with gap-6)

**Taskbar** (Bottom bar):
- Fixed bottom, full width, height h-12
- Three sections: Start button (left) | Open apps (center) | System tray (right)
- Start button: 48px width with icon
- App icons: 40px width each, gap-2
- System tray widgets: flex layout, gap-4, px-4

**Start Menu**:
- Popup from taskbar, 320px width, max-h-96
- Search bar at top (h-10)
- Scrollable app list below
- App items: Full width, h-10, with icon (20px) + label

### Window System

**Window Chrome** (Title bar):
- Height h-8
- Flex layout: Title (flex-1) | Window controls (min/max/close)
- Draggable cursor, backdrop-blur effect
- Control buttons: 32px width each, gap-1

**Window Container**:
- Minimum size: 400px × 300px
- Default size: 800px × 600px
- Border: 2px solid
- Rounded corners: rounded-lg
- Drop shadow: Deep, layered shadow for depth
- Resizable handles on all edges/corners

**Window Content Area**:
- Padding: p-0 (apps control their own padding)
- Scroll behavior: Per-app basis (terminal no scroll, file manager scrolls)

### Applications

**Browser Window**:
- Address bar: h-10, full width, px-4
- Navigation buttons: 32px × 32px, gap-2
- Tab bar: h-9, scrollable horizontal
- Content iframe: Remaining height minus controls

**Terminal**:
- Full padding: p-4
- Monospace font throughout
- Pre-formatted text display
- Input line at bottom with prompt indicator
- Auto-scroll to latest output

**File Manager**:
- Sidebar: w-48 (folder tree)
- Main area: flex-1 (file grid or list)
- Toolbar: h-10 (breadcrumb navigation + view options)
- File grid: grid-cols-4 gap-4 for icons view
- File list: Full width rows with columns for name/size/date

**Notes/Text Editor**:
- Toolbar: h-10 (formatting options)
- Text area: flex-1, p-4
- Line numbers gutter: w-12 (if enabled)
- Status bar: h-6 bottom (line/column count)

### Widgets & System Components

**System Monitor Widgets** (Taskbar):
- Compact inline display
- Icon + value pairs (CPU icon + "45%" | RAM icon + "2.1GB")
- Clock: HH:MM format, date on hover tooltip

**Context Menus**:
- Width: 200px minimum
- Item height: h-8
- Dividers: 1px border between groups
- Submenu arrows on right for nested items

**Modal Dialogs**:
- Centered viewport positioning
- Width: 400-600px depending on content
- Backdrop: Semi-transparent overlay (backdrop-blur-sm)
- Padding: p-6
- Button group at bottom: gap-3, justify-end

## Interaction Patterns

**Window Management**:
- Click title bar to drag (cursor-move)
- Double-click title bar to maximize
- Drag edges/corners to resize (appropriate cursors)
- Click outside modals to dismiss
- Alt+Tab style app switcher (future enhancement)

**Navigation**:
- Single-click to select
- Double-click to open
- Right-click for context menus
- Breadcrumb navigation in file manager

## Animations

**Minimal, Purposeful Motion**:
- Window open: Scale from 0.95 to 1.0, fade in (150ms)
- Window close: Fade out (100ms)
- Menu appearance: Slide down + fade (120ms)
- NO continuous animations, NO scroll-triggered effects
- Hover states: Instant (0ms transition)

## Accessibility

- High contrast text on all backgrounds
- Focus visible states for all interactive elements (2px outline offset)
- Keyboard navigation: Tab through windows, arrow keys in lists
- Screen reader labels on icon-only buttons
- Maintain 4.5:1 contrast ratio minimum

## Images

**Desktop Wallpaper**:
- Full viewport background image (100vw × 100vh)
- Cyberpunk/space/tech aesthetic with depth
- Position: center/cover
- Slightly darkened overlay for text legibility

**App Icons**:
- Use icon library (Heroicons or Lucide) for consistency
- Size: 20px in menus, 24px in taskbar, 48px for desktop icons
- Monochrome with theme-appropriate treatment

**ASCII Art**:
- "HAPYLAND OS" logo positioned top-left (top-8 left-8)
- Monospace font, large scale (text-lg or text-xl)
- High visibility treatment against wallpaper