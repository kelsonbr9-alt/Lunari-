# Hapyland OS - Sistema Operacional Web

## Visão Geral

Hapyland OS é um sistema operacional completo rodando no navegador, desenvolvido com React, TypeScript e Node.js. Ele simula um ambiente desktop Linux com janelas arrastáveis, terminal real via WebSocket, navegador web integrado, gerenciador de arquivos e editor de texto.

## Última Atualização

**Data**: 16 de Novembro de 2025  
**Status**: MVP completo com todos os componentes principais implementados

## Funcionalidades Principais

### Desktop Shell
- Desktop completo com wallpaper cyberpunk (imagem do usuário)
- ASCII art "HAPYLAND OS" no canto superior esquerdo
- Sistema de janelas arrastáveis e redimensionáveis
- Suporte para minimizar, maximizar e fechar janelas
- Z-index automático ao clicar em janelas

### Aplicativos

1. **Navegador Web**
   - Barra de endereços funcional
   - Navegação (voltar, avançar, recarregar, home)
   - Suporta URLs diretas ou busca no Google
   - Sandbox iframe para segurança

2. **Terminal**
   - Conexão WebSocket em tempo real com servidor
   - Execução de comandos bash reais
   - Histórico de comandos (seta cima/baixo)
   - Indicador de status de conexão
   - Auto-scroll

3. **Gerenciador de Arquivos**
   - Sistema de arquivos virtual em memória
   - Navegação por breadcrumb
   - Tree view de pastas
   - Visualização de tamanho e data de modificação
   - Estrutura inicial: /home/Documentos, /home/Downloads, /home/Imagens

4. **Bloco de Notas**
   - Editor de texto com syntax highlighting
   - Contador de linhas, palavras e caracteres
   - Indicador de salvamento
   - Suporte a UTF-8

### Taskbar (Barra de Tarefas)

- Posicionada na parte inferior da tela
- Botão "Start Menu" para lançar aplicativos
- Janelas abertas como botões minimizáveis
- System Tray com widgets em tempo real:
  - CPU usage %
  - Memory usage %
  - Relógio (hora e data)

### Start Menu

- Busca de aplicativos
- Lista de todos os apps disponíveis com ícones e descrições
- Fechar clicando fora do menu

## Arquitetura

### Frontend (React + TypeScript)

**Estrutura de Componentes:**
```
client/src/
├── components/
│   ├── Desktop.tsx          # Shell principal do OS
│   ├── Window.tsx           # Componente de janela genérica
│   ├── Taskbar.tsx          # Barra de tarefas
│   ├── StartMenu.tsx        # Menu iniciar
│   └── apps/
│       ├── BrowserApp.tsx   # Navegador web
│       ├── TerminalApp.tsx  # Terminal WebSocket
│       ├── FileManagerApp.tsx # Gerenciador de arquivos
│       └── NotesApp.tsx     # Editor de texto
├── pages/
│   └── Home.tsx             # Página principal
└── App.tsx                  # Root component
```

**Estado de Janelas:**
- Gerenciado no componente Desktop
- Cada janela tem: id, appId, título, posição (x, y), tamanho (width, height), zIndex
- Suporte para arrastar (drag) e redimensionar (resize)

### Backend (Node.js + Express + WebSocket)

**Endpoints de API:**
- `GET /api/system/metrics` - Retorna CPU e RAM em tempo real
- `GET /api/files` - Lista todos os arquivos do sistema virtual
- `POST /api/files` - Cria novo arquivo/pasta
- `PUT /api/files/:path` - Atualiza conteúdo de arquivo
- `DELETE /api/files/:path` - Remove arquivo/pasta

**WebSocket (`/ws`):**
- Terminal interativo em tempo real
- Executa comandos bash com `child_process.exec`
- Timeout de 10 segundos por comando
- Resposta com stdout/stderr

**Storage (MemStorage):**
- Armazenamento em memória para arquivos virtuais
- Sistema de arquivos hierárquico com FileNode
- Métricas do sistema usando `os` module

### Schemas (TypeScript)

```typescript
// shared/schema.ts
interface FileNode {
  id: string;
  name: string;
  type: "file" | "folder";
  path: string;
  content?: string;
  children?: FileNode[];
  size?: number;
  modified?: Date;
}

interface SystemMetrics {
  cpu: number;
  memory: number;
  timestamp: number;
}

interface WindowState {
  id: string;
  appId: AppId;
  title: string;
  x, y, width, height: number;
  isMinimized, isMaximized: boolean;
  zIndex: number;
}
```

## Design System

### Tema Cyberpunk Dark

**Cores Principais:**
- Background: `270 15% 8%` (roxo muito escuro)
- Foreground: `270 15% 95%` (texto claro)
- Primary: `270 85% 55%` (roxo vibrante)
- Card: `270 14% 10%` (fundo de janelas)
- Sidebar: `270 13% 12%` (taskbar e title bars)

**Fontes:**
- Sans: Inter
- Mono: JetBrains Mono (terminal, código)

**Componentes:**
- Shadcn UI components (Button, Input, Textarea, ScrollArea, Badge, etc.)
- Elevação automática em hover/active com `hover-elevate` e `active-elevate-2`
- Bordas arredondadas: `rounded-lg` (9px)

## Tecnologias

- **Frontend**: React 18, TypeScript, Vite, TailwindCSS, Shadcn UI, Wouter (routing), TanStack Query
- **Backend**: Node.js, Express, WebSocket (ws), child_process
- **Build**: Vite com HMR
- **Estado**: React useState/useEffect, TanStack Query para server state

## Como Rodar

O workflow "Start application" já está configurado e executa:
```bash
npm run dev
```

Isso inicia:
- Backend Express na porta 5000
- Frontend Vite com proxy
- WebSocket server em /ws

## Próximas Melhorias (Fase 2)

- [ ] Gerenciador de processos (matar apps)
- [ ] Múltiplos desktops/workspaces
- [ ] Player de música com visualizador
- [ ] Editor de código completo (Monaco Editor)
- [ ] Sistema de notificações
- [ ] Configurações (wallpaper, tema, widgets)
- [ ] Persistência de estado (localStorage)
- [ ] Drag & drop de arquivos entre apps

## Preferências do Usuário

- Idioma: Português (PT-BR)
- Estilo visual: Cyberpunk dark com tons de roxo/azul/preto
- Wallpaper: Imagem anexada pelo usuário (anime cyberpunk)

## Notas Técnicas

- Todas as janelas são arrastáveis pela barra de título
- Redimensionamento pelas bordas e cantos
- WebSocket reconecta automaticamente em caso de desconexão
- Comandos do terminal têm timeout de 10s
- Sistema de arquivos é volátil (resetado ao reiniciar)
- Dark mode sempre ativo (classe `.dark` no html)
