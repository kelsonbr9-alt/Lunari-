import { useState } from "react";
import { Textarea } from "../ui/textarea";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Save, FileText } from "lucide-react";

export function NotesApp() {
  const [content, setContent] = useState(
    "# Bem-vindo ao Bloco de Notas do Hapyland OS!\n\nDigite aqui suas anotações..."
  );
  const [isSaved, setIsSaved] = useState(true);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
    setIsSaved(false);
  };

  const handleSave = () => {
    setIsSaved(true);
  };

  const lineCount = content.split("\n").length;
  const wordCount = content.trim().split(/\s+/).filter(Boolean).length;
  const charCount = content.length;

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="p-2 border-b border-border bg-sidebar flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileText className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium">Sem título</span>
          {!isSaved && (
            <Badge variant="secondary" className="text-xs">
              Não salvo
            </Badge>
          )}
        </div>

        <Button
          size="sm"
          variant="default"
          className="h-8 gap-2"
          onClick={handleSave}
          disabled={isSaved}
          data-testid="button-save-note"
        >
          <Save className="h-3 w-3" />
          Salvar
        </Button>
      </div>

      <div className="flex-1 overflow-hidden">
        <Textarea
          value={content}
          onChange={handleChange}
          className="h-full resize-none border-0 rounded-none focus-visible:ring-0 font-mono text-sm p-4"
          placeholder="Digite suas anotações aqui..."
          data-testid="textarea-notes"
        />
      </div>

      <div className="p-2 border-t border-border bg-sidebar flex items-center justify-between text-xs text-muted-foreground">
        <div className="flex items-center gap-4">
          <span data-testid="stat-lines">Linhas: {lineCount}</span>
          <span data-testid="stat-words">Palavras: {wordCount}</span>
          <span data-testid="stat-chars">Caracteres: {charCount}</span>
        </div>
        <div className="flex items-center gap-2">
          <span>UTF-8</span>
        </div>
      </div>
    </div>
  );
}
