import { useState } from "react";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { ArrowLeft, ArrowRight, RotateCw, Home, Search, ExternalLink } from "lucide-react";
import { Badge } from "../ui/badge";

const SAFE_SITES = [
  { name: "Wikipedia", url: "https://pt.wikipedia.org" },
  { name: "GitHub", url: "https://github.com" },
  { name: "Stack Overflow", url: "https://stackoverflow.com" },
  { name: "MDN", url: "https://developer.mozilla.org" },
];

export function BrowserApp() {
  const [url, setUrl] = useState("https://www.google.com/search?igu=1");
  const [inputValue, setInputValue] = useState(url);
  const [iframeKey, setIframeKey] = useState(0);
  const [history, setHistory] = useState<string[]>(["https://www.google.com/search?igu=1"]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const [showWarning, setShowWarning] = useState(false);

  const navigate = (newUrl: string, addToHistory = true) => {
    let finalUrl = newUrl.trim();
    
    if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
      if (finalUrl.includes(".") && !finalUrl.includes(" ")) {
        finalUrl = "https://" + finalUrl;
      } else {
        finalUrl = "https://www.google.com/search?igu=1&q=" + encodeURIComponent(finalUrl);
      }
    }
    
    setUrl(finalUrl);
    setInputValue(finalUrl);
    setIframeKey(prev => prev + 1);
    setShowWarning(true);

    if (addToHistory) {
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(finalUrl);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    }

    setTimeout(() => setShowWarning(false), 3000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(inputValue);
  };

  const goBack = () => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      const newUrl = history[newIndex];
      setUrl(newUrl);
      setInputValue(newUrl);
      setIframeKey(prev => prev + 1);
    }
  };

  const goForward = () => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      setHistoryIndex(newIndex);
      const newUrl = history[newIndex];
      setUrl(newUrl);
      setInputValue(newUrl);
      setIframeKey(prev => prev + 1);
    }
  };

  const reload = () => {
    setIframeKey(prev => prev + 1);
  };

  const goHome = () => {
    navigate("https://www.google.com/search?igu=1");
  };

  const openInNewTab = () => {
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const canGoBack = historyIndex > 0;
  const canGoForward = historyIndex < history.length - 1;

  return (
    <div className="h-full flex flex-col bg-card">
      <div className="p-2 border-b border-card-border flex items-center gap-2 bg-sidebar">
        <div className="flex items-center gap-1">
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8"
            disabled={!canGoBack}
            onClick={goBack}
            data-testid="button-browser-back"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8"
            disabled={!canGoForward}
            onClick={goForward}
            data-testid="button-browser-forward"
          >
            <ArrowRight className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8"
            onClick={reload}
            data-testid="button-browser-reload"
          >
            <RotateCw className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8"
            onClick={goHome}
            data-testid="button-browser-home"
          >
            <Home className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8"
            onClick={openInNewTab}
            data-testid="button-browser-external"
            title="Abrir em nova aba"
          >
            <ExternalLink className="h-4 w-4" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              className="pl-9 h-8 bg-background"
              placeholder="Digite uma URL ou busque no Google..."
              data-testid="input-browser-url"
            />
          </div>
        </form>
      </div>

      {showWarning && (
        <div className="p-2 bg-muted border-b border-border">
          <Badge variant="secondary" className="text-xs">
            ℹ️ Alguns sites podem bloquear carregamento em iframe. Use o botão de abrir em nova aba se necessário.
          </Badge>
        </div>
      )}

      <div className="p-2 border-b border-border bg-sidebar/50 flex items-center gap-2 flex-wrap">
        <span className="text-xs text-muted-foreground">Links rápidos:</span>
        {SAFE_SITES.map(site => (
          <Button
            key={site.url}
            size="sm"
            variant="ghost"
            className="h-6 text-xs"
            onClick={() => navigate(site.url)}
          >
            {site.name}
          </Button>
        ))}
      </div>

      <div className="flex-1 relative bg-background">
        <iframe
          key={iframeKey}
          src={url}
          className="w-full h-full border-0"
          sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox"
          title="Navegador Web"
          data-testid="iframe-browser"
        />
      </div>
    </div>
  );
}
