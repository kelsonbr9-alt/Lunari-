import { Desktop } from "@/components/Desktop";

export default function Home() {
  return <Desktop />;
}
