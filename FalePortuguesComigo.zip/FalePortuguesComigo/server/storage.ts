import { type FileNode, type SystemMetrics } from "@shared/schema";
import { randomUUID } from "crypto";
import os from "os";

export interface IStorage {
  getSystemMetrics(): Promise<SystemMetrics>;
  getFiles(): Promise<FileNode[]>;
  createFile(parentPath: string, file: Omit<FileNode, 'id' | 'path'>): Promise<FileNode>;
  updateFile(path: string, content: string): Promise<FileNode | undefined>;
  deleteFile(path: string): Promise<boolean>;
}

function normalizePath(path: string): string {
  return path.startsWith("/") ? path : "/" + path;
}

export class MemStorage implements IStorage {
  private root: FileNode;

  constructor() {
    this.root = this.initializeDefaultFiles();
  }

  private initializeDefaultFiles(): FileNode {
    return {
      id: "root",
      name: "root",
      type: "folder",
      path: "/",
      children: [
        {
          id: "home",
          name: "home",
          type: "folder",
          path: "/home",
          children: [
            {
              id: "documents",
              name: "Documentos",
              type: "folder",
              path: "/home/Documentos",
              children: [
                {
                  id: "readme",
                  name: "readme.txt",
                  type: "file",
                  path: "/home/Documentos/readme.txt",
                  content: "Bem-vindo ao Hapyland OS!\n\nDesenvolvido por Kelson",
                  size: 50,
                  modified: new Date(),
                },
              ],
            },
            {
              id: "downloads",
              name: "Downloads",
              type: "folder",
              path: "/home/Downloads",
              children: [],
            },
            {
              id: "pictures",
              name: "Imagens",
              type: "folder",
              path: "/home/Imagens",
              children: [],
            },
          ],
        },
      ],
    };
  }

  private findNodeByPath(path: string, node: FileNode = this.root): FileNode | undefined {
    const normalizedPath = normalizePath(path);
    if (node.path === normalizedPath) return node;
    if (!node.children) return undefined;

    for (const child of node.children) {
      const found = this.findNodeByPath(normalizedPath, child);
      if (found) return found;
    }
    return undefined;
  }

  private deleteNodeRecursive(node: FileNode, targetPath: string): boolean {
    if (!node.children) return false;

    const normalizedPath = normalizePath(targetPath);
    
    for (let i = 0; i < node.children.length; i++) {
      const child = node.children[i];
      if (child.path === normalizedPath) {
        node.children.splice(i, 1);
        return true;
      }
      if (child.children && child.path.length < normalizedPath.length && normalizedPath.startsWith(child.path + "/")) {
        if (this.deleteNodeRecursive(child, normalizedPath)) {
          return true;
        }
      }
    }

    return false;
  }

  async getSystemMetrics(): Promise<SystemMetrics> {
    const cpuUsage = os.loadavg()[0] / os.cpus().length * 100;
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const memoryUsage = ((totalMem - freeMem) / totalMem) * 100;

    return {
      cpu: Math.min(100, Math.max(0, cpuUsage)),
      memory: Math.min(100, Math.max(0, memoryUsage)),
      timestamp: Date.now(),
    };
  }

  async getFiles(): Promise<FileNode[]> {
    return [this.root];
  }

  async createFile(parentPath: string, fileData: Omit<FileNode, 'id' | 'path'>): Promise<FileNode> {
    const normalizedParentPath = normalizePath(parentPath);
    const parent = this.findNodeByPath(normalizedParentPath);
    
    if (!parent || parent.type !== "folder") {
      throw new Error(`Parent folder not found: ${normalizedParentPath}`);
    }

    const fullPath = normalizedParentPath === "/" 
      ? "/" + fileData.name 
      : normalizedParentPath + "/" + fileData.name;

    const existing = this.findNodeByPath(fullPath);
    if (existing) {
      throw new Error(`File already exists: ${fullPath}`);
    }

    const newFile: FileNode = {
      ...fileData,
      id: randomUUID(),
      path: fullPath,
      modified: new Date(),
      size: fileData.content?.length || 0,
    };

    if (!parent.children) {
      parent.children = [];
    }

    parent.children.push(newFile);
    return newFile;
  }

  async updateFile(path: string, content: string): Promise<FileNode | undefined> {
    const normalizedPath = normalizePath(path);
    const file = this.findNodeByPath(normalizedPath);
    
    if (!file || file.type !== "file") {
      return undefined;
    }

    file.content = content;
    file.size = content.length;
    file.modified = new Date();
    return file;
  }

  async deleteFile(path: string): Promise<boolean> {
    const normalizedPath = normalizePath(path);
    
    if (normalizedPath === "/" || normalizedPath === "/home") {
      throw new Error("Cannot delete root or home directory");
    }

    return this.deleteNodeRecursive(this.root, normalizedPath);
  }
}

export const storage = new MemStorage();
